if [ -z "${XDG_RUNTIME_DIR:-}" ]; then
    ylva_audio_user="$(id -un 2>/dev/null || printf ylva)"
    export XDG_RUNTIME_DIR="/tmp/ylva-runtime-$ylva_audio_user"
fi
mkdir -p "$XDG_RUNTIME_DIR" "$XDG_RUNTIME_DIR/pulse" 2>/dev/null || true
chmod 700 "$XDG_RUNTIME_DIR" 2>/dev/null || true
export PULSE_SERVER="${PULSE_SERVER:-unix:$XDG_RUNTIME_DIR/pulse/native}"
export ALSA_CONFIG_PATH=/etc/asound.conf
export PULSE_PROP="media.role=game"
