export MUSL_LOCPATH=/usr/share/i18n/locales/musl
export LANG=ja_JP.UTF-8
export LC_CTYPE=ja_JP.UTF-8
export LC_MESSAGES=C.UTF-8
