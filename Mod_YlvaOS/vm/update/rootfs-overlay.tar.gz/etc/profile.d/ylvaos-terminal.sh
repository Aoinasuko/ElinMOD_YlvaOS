export PATH=/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
export MUSL_LOCPATH=/usr/share/i18n/locales/musl
export LANG=ja_JP.UTF-8
export LC_CTYPE=ja_JP.UTF-8
export LC_MESSAGES=C.UTF-8
export TERM=vt100
stty rows 32 cols 140 -ixon 2>/dev/null || true
